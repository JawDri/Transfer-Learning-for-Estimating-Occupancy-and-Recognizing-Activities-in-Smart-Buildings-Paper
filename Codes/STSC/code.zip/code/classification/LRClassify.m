function TestOut = LRClassify(LearnOut, Options)
% LRCLASSIFY Applies logistic regression to the input data.
%            Returns the Output structure with true labels, scores,
%            predictions, and accuracy.
% =========================================================================

TrainSet = LearnOut.TrainSet;
TestSet = LearnOut.TestSet;
LabeledTrainIdx = find(TrainSet.Labeled == 1);
SourceTestIdx = find(TestSet.DomainIdx == 1);
TargetTestIdx = find(TestSet.DomainIdx == -1);

classOrder = unique(TrainSet.Labels);

tree = fitctree(TrainSet.Features(:,LabeledTrainIdx)',TrainSet.Labels(LabeledTrainIdx)');
labels = predict(tree,TestSet.Features');



TestOut.Predictions = [];
TestOut.F1_Score = [];
TestOut.Precision = [];
TestOut.Recall = [];

TestOut.Predictions = [TestOut.Predictions labels];
if length(classOrder) == 5
    
    [TP_1, TN_1, FP_1, FN_1, Precision_1, Recall_1, F1_score_1] = Confusion_Matrix(60, labels, TestSet.Labels');
    [TP_2, TN_2, FP_2, FN_2, Precision_2, Recall_2, F1_score_2] = Confusion_Matrix(15, labels, TestSet.Labels');
    [TP_3, TN_3, FP_3, FN_3, Precision_3, Recall_3, F1_score_3] = Confusion_Matrix(65, labels, TestSet.Labels');
    [TP_4, TN_4, FP_4, FN_4, Precision_4, Recall_4, F1_score_4] = Confusion_Matrix(85, labels, TestSet.Labels');
    [TP_5, TN_5, FP_5, FN_5, Precision_5, Recall_5, F1_score_5] = Confusion_Matrix(70, labels, TestSet.Labels');
    
    Precision = (TP_1 + TP_2 + TP_3 + TP_4 + TP_5)/((TP_1 + TP_2 + TP_3 + TP_4 + TP_5) + (FP_1 + FP_2 + FP_3 + FP_4 + FP_5));
    Recall = (TP_1 + TP_2 + TP_3 + TP_4 + TP_5)/((TP_1 + TP_2 + TP_3 + TP_4 + TP_5) + (FN_1 + FN_2 + FN_3 + FN_4 + FN_5));
    F1_score = 2*Precision*Recall/(Precision + Recall);
    
    TestOut.F1_Score = [F1_score F1_score_1 F1_score_2 F1_score_3 F1_score_4 F1_score_5 ];
    TestOut.Precision = [Precision Precision_1 Precision_2 Precision_3 Precision_4 Precision_5];
    TestOut.Recall = [Recall Recall_1 Recall_2 Recall_3 Recall_4 Recall_5];
    
elseif length(classOrder) == 3
    labels
    [TP_1, TN_1, FP_1, FN_1, Precision_1, Recall_1, F1_score_1] = Confusion_Matrix(0, labels, TestSet.Labels');
    [TP_2, TN_2, FP_2, FN_2, Precision_2, Recall_2, F1_score_2] = Confusion_Matrix(1, labels, TestSet.Labels');
    [TP_3, TN_3, FP_3, FN_3, Precision_3, Recall_3, F1_score_3] = Confusion_Matrix(2, labels, TestSet.Labels');

    
    Precision = (TP_1 + TP_2 + TP_3)/((TP_1 + TP_2 + TP_3) + (FP_1 + FP_2 + FP_3));
    Recall = (TP_1 + TP_2 + TP_3)/((TP_1 + TP_2 + TP_3) + (FN_1 + FN_2 + FN_3));
    F1_score = 2*Precision*Recall/(Precision + Recall);
    
    TestOut.F1_Score = [F1_score F1_score_1 F1_score_2 F1_score_3];
    TestOut.Precision = [Precision Precision_1 Precision_2 Precision_3];
    TestOut.Recall = [Recall Recall_1 Recall_2 Recall_3];
    

end



end
