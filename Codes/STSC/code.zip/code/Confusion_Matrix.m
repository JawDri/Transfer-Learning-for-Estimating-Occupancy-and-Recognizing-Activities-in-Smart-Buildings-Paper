function [TP, TN, FP, FN, Precision, Recall, F1_score] = Confusion_Matrix(class, predicted, gnd)
TP = 0;
TN = 0;
FP = 0;
FN = 0;
for i=1:length(predicted)
    if predicted(i) == class && gnd(i) == class
        TP = TP + 1;
        
    elseif predicted (i) == class && gnd(i) ~= class
        FP = FP + 1;
        
    elseif gnd(i) == class && predicted(i) ~= class
        FN = FN + 1;
        
    elseif gnd(i) ~= class && predicted(i) ~= class
        TN = TN + 1;
        
        
        
    end



end
Precision = TP/(TP + FP);
Recall = TP/(TP + FN);
F1_score = 2*Precision*Recall/(Precision + Recall);


end

