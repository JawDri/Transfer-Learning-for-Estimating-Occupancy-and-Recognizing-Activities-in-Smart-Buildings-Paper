function [Precisions, Recalls, F1_Scores] = CrossValidation(config, cv, seed, verbose)
% CROSSVALIDATION Performs SingleRun several times with different seeds,
%                 accumulates the accuracy results and returns the average.
% =========================================================================
if ~exist('cv','var'); cv = 10; end
if ~exist('seed','var'); seed = 42; end
if ~exist('verbose','var'); verbose = true; end

% Initialize accuracies
cl_meth = config.ClassificationMethods;

Precisions = cell(1, cv);
Recalls = cell(1, cv);
F1_Scores = cell(1, cv);

if 1; fprintf('Cross-validating...\n'); end
parfor i=1:cv
  if 1; fprintf('  Iteration %d/%d\n',i,cv); end
  RunOutput = SingleRun(config, i*seed);
  for j=1:numel(cl_meth)
    meth = cl_meth{j};
    
    Precisions{i}.(meth) = RunOutput.Test.(meth).Precision;
    Recalls{i}.(meth) = RunOutput.Test.(meth).Recall;
    F1_Scores{i}.(meth) = RunOutput.Test.(meth).F1_Score;

  end
end
if 1; fprintf('Done.\n'); end


end